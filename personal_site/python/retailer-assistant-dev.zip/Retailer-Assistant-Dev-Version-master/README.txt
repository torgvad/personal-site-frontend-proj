Welcome to the Retail Assistant. I am Vadim Torgashov and this is my senior capstone for BVU.
This program will automatically search online retailers for newly added listings of whatever you want.
You can type in a search, select the retailer you want to search, price range, time interval, max shipping cost, and words/phrases you want to exclude from the title.

The time interval is how often the program will search the website to find that query. 
The things you search for should be fairly specific to avoid excssivly searching the website.
Searches that are too broad will give a warning window and stop searching for that item, so be aware of what time interval you select.

Words/phrases added to the exclude entry must be seperated by commas with no spaces. 
So if you want to exclude the words used, good, and rusted they must written as "used,good,rusted" or else the program wil interpert it as one continious phrase.

The queries tab is to look at stored listings, delete listings, delete queries, or to save stored listings to a .txt file.